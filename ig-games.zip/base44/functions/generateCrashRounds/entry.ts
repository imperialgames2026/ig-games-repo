import { createClientFromRequest } from 'npm:@base44/sdk@0.8.20';

const HOUSE_EDGE = 0.07;

function fastHash(seed) {
  let h = 5381;
  for (let i = 0; i < seed.length; i++) {
    h = ((h << 5) + h) ^ seed.charCodeAt(i);
    h = h >>> 0;
  }
  return h.toString(16).padStart(8, '0') +
         (h * 0x9e3779b9 >>> 0).toString(16).padStart(8, '0') +
         (h ^ (h >>> 16)).toString(16).padStart(8, '0') +
         (h * 0x85ebca6b >>> 0).toString(16).padStart(8, '0');
}

function generateSeed() {
  const buf = new Uint8Array(8);
  crypto.getRandomValues(buf);
  return Array.from(buf).map(b => b.toString(16).padStart(2,'0')).join('') + '-' + Date.now().toString(36);
}

function randomF() {
  const a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return a[0] / 0x100000000;
}

function makeCrashPoint() {
  const r = randomF();
  // 7% house edge: instant bust at 1.00
  if (r < HOUSE_EDGE) return 1.00;
  // Standard inverse distribution for the rest
  const crash = 0.99 / (1 - r);
  return Math.round(Math.min(crash, 100.00) * 100) / 100;
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    let user = null;
    try { user = await base44.auth.me(); } catch (_) {}

    if (!user || (user.role !== 'admin' && user.role !== 'superadmin')) {
      return Response.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const count = Math.min(25, Math.max(1, parseInt(body.count) || 25));

    const existingRounds = await base44.asServiceRole.entities.CrashRound.list('-round_number', 1);
    const nextRoundNumber = (existingRounds[0]?.round_number || 0) + 1;

    const rounds = [];
    for (let i = 0; i < count; i++) {
      const seed = generateSeed();
      rounds.push({
        round_number: nextRoundNumber + i,
        seed,
        hash: fastHash(seed),
        crash_point: makeCrashPoint(),
        status: 'pending',
        house_edge: HOUSE_EDGE
      });
    }

    await base44.asServiceRole.entities.CrashRound.bulkCreate(rounds);

    return Response.json({
      success: true,
      generated: count,
      starting_round: nextRoundNumber
    });
  } catch (error) {
    console.error('generateCrashRounds error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});