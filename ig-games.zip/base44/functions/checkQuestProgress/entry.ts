import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const response = await base44.functions.invoke('processQuestEvent', payload);
    return Response.json(response.data);
  } catch (error) {
    console.error('Quest check error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});