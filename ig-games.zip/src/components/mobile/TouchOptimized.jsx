// Global utility for touch-friendly button sizes
export const touchTargetClasses = 'min-h-[44px] min-w-[44px] flex items-center justify-center';

// Apply to all interactive elements:
// - Buttons: className={`${touchTargetClasses} ...`}
// - Game controls: className={`${touchTargetClasses} ...`}
// - Tabs: className={`${touchTargetClasses} ...`}